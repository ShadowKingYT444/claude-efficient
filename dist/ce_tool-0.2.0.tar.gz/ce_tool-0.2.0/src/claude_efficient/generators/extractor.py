"""Phase 4: Deterministic project fact extraction. No file contents are read."""
from __future__ import annotations

import ast
import json
from dataclasses import dataclass, field
from pathlib import Path

ALWAYS_SKIP = {
    "__pycache__", ".git", "node_modules", ".next", "dist", "build",
    ".ruff_cache", ".mypy_cache", ".venv", "venv",
}

LANGUAGE_EXTENSIONS: dict[str, set[str]] = {
    "python":     {".py"},
    "typescript": {".ts", ".tsx", ".js", ".jsx"},
    "go":         {".go"},
    "rust":       {".rs"},
}

QUALIFY_THRESHOLDS: dict[str, int] = {
    "python":     5,
    "typescript": 5,
    "go":         3,
    "rust":       3,
}

KEY_CONFIG_NAMES = {
    "pyproject.toml", "package.json", "go.mod", "Cargo.toml",
    "Makefile", "setup.py", "setup.cfg", "requirements.txt",
    ".env.example", "docker-compose.yml", "Dockerfile",
    "tsconfig.json", ".eslintrc.json", "jest.config.js",
}


@dataclass
class SubdirCandidate:
    path: str
    language: str
    file_count: int
    qualifies: bool
    files: dict[str, str] = field(default_factory=dict)
    key_file_contents: dict[str, str] = field(default_factory=dict)


@dataclass
class ExtractedFacts:
    tree: list[str] = field(default_factory=list)
    commands: dict[str, str] = field(default_factory=dict)
    languages: list[str] = field(default_factory=list)
    key_configs: list[str] = field(default_factory=list)
    key_file_contents: dict[str, str] = field(default_factory=dict)
    subdir_candidates: list[SubdirCandidate] = field(default_factory=list)


def extract_facts(project_root: Path) -> ExtractedFacts:
    facts = ExtractedFacts()
    facts.tree, facts.key_file_contents = _scan_tree(project_root)
    facts.commands = _extract_commands(project_root)
    facts.languages = _detect_languages(project_root)
    facts.key_configs = _find_key_configs(project_root)
    facts.subdir_candidates = _find_subdir_candidates(project_root)
    return facts


def _get_file_desc(path: Path) -> str:
    if path.suffix != ".py":
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
            for line in content.splitlines():
                line = line.strip()
                if not line:
                    continue
                if line.startswith(('"""', "'''")):
                    return line.strip(" \"'")[:100]
                if line.startswith(("#", "//", "/*", "*", "<!--")):
                    cleaned = line.lstrip("#/ *<!-").strip()
                    if cleaned:
                        return cleaned[:100]
                if line.startswith(("import ", "from ", "package ", "use ")):
                    if "__future__" in line:
                        continue
                    break
        except Exception:
            pass
        return ""

    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(content)
        symbols = []
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                symbols.append(f"def {node.name}()")
            elif isinstance(node, ast.AsyncFunctionDef):
                symbols.append(f"async def {node.name}()")
            elif isinstance(node, ast.ClassDef):
                symbols.append(f"class {node.name}")
        return ", ".join(symbols)
    except Exception:
        return ""


def _scan_tree(root: Path, max_entries: int = 15) -> tuple[list[str], dict[str, str]]:
    entries: list[str] = []
    key_files: dict[str, str] = {}
    key_file_names = {"main.py", "cli.py", "app.py", "index.ts", "lib.rs", "mod.go"}
    try:
        for entry in sorted(root.iterdir(), key=lambda p: (p.is_file(), p.name)):
            if entry.name in ALWAYS_SKIP or entry.name.startswith("."):
                continue
            rel = entry.relative_to(root)
            if entry.is_dir():
                entries.append(f"{rel}/")
            else:
                desc = _get_file_desc(entry)
                entries.append(f"{rel} - {desc}" if desc else str(rel))
                if entry.name in key_file_names and len(key_files) < 5:
                    try:
                        content = entry.read_text(encoding="utf-8", errors="ignore")
                        if len(content.encode()) < 8000:
                            key_files[str(rel)] = content
                    except Exception:
                        pass
            if len(entries) >= max_entries:
                break
    except (PermissionError, OSError):
        pass
    return entries, key_files


def _detect_languages(root: Path) -> list[str]:
    counts: dict[str, int] = {}
    try:
        for f in root.rglob("*"):
            if not f.is_file():
                continue
            if any(skip in f.parts for skip in ALWAYS_SKIP):
                continue
            for lang, exts in LANGUAGE_EXTENSIONS.items():
                if f.suffix in exts:
                    counts[lang] = counts.get(lang, 0) + 1
    except (PermissionError, OSError):
        pass
    return [lang for lang, _ in sorted(counts.items(), key=lambda x: -x[1])]


def _find_key_configs(root: Path, max_configs: int = 12) -> list[str]:
    configs: list[str] = []
    try:
        for entry in root.iterdir():
            if entry.name in KEY_CONFIG_NAMES and entry.is_file():
                configs.append(str(entry.relative_to(root)))
    except (PermissionError, OSError):
        pass
    return sorted(configs)[:max_configs]


def _find_subdir_candidates(root: Path) -> list[SubdirCandidate]:
    candidates: list[SubdirCandidate] = []
    try:
        subdirs = [
            d for d in sorted(root.rglob("*/"))
            if d.is_dir() and not any(skip in d.parts for skip in ALWAYS_SKIP)
        ]
    except (PermissionError, OSError):
        return []
    for subdir in subdirs:
        for lang, exts in LANGUAGE_EXTENSIONS.items():
            count = 0
            files_desc: dict[str, str] = {}
            key_contents: dict[str, str] = {}
            for ext in exts:
                try:
                    for f in subdir.glob(f"*{ext}"):
                        count += 1
                        if len(files_desc) < 20:
                            desc = _get_file_desc(f)
                            files_desc[f.name] = desc
                        if f.name == "__init__.py" and not key_contents:
                             try:
                                content = f.read_text(encoding="utf-8", errors="ignore")
                                if len(content.encode()) < 4000:
                                    key_contents[f.name] = content
                             except Exception:
                                pass
                except (PermissionError, OSError):
                    pass
            if count > 0:
                candidates.append(SubdirCandidate(
                    path=str(subdir.relative_to(root)).replace("\\", "/"),
                    language=lang,
                    file_count=count,
                    qualifies=count >= QUALIFY_THRESHOLDS[lang],
                    files=files_desc,
                    key_file_contents=key_contents,
                ))
    return candidates


def _extract_commands(root: Path) -> dict[str, str]:
    cmds: dict[str, str] = {}

    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        try:
            import tomllib
            with open(pyproject, "rb") as f:
                data = tomllib.load(f)
            scripts = (
                data.get("tool", {}).get("poetry", {}).get("scripts", {})
                or data.get("project", {}).get("scripts", {})
            )
            if scripts:
                cmds.setdefault("run", next(iter(scripts)))
            if data.get("tool", {}).get("pytest") is not None or "pytest" in str(
                data.get("project", {}).get("dependencies", [])
            ):
                cmds.setdefault("test", "pytest tests/ -x")
            if data.get("tool", {}).get("ruff") is not None:
                cmds.setdefault("lint", "ruff check .")
        except Exception:
            pass

    pkg_json = root / "package.json"
    if pkg_json.exists():
        try:
            data = json.loads(pkg_json.read_text(encoding="utf-8", errors="replace"))
            scripts = data.get("scripts", {})
            for cmd, key in [
                ("run", "start"), ("run", "dev"), ("test", "test"),
                ("build", "build"), ("lint", "lint"),
            ]:
                if key in scripts:
                    cmds.setdefault(cmd, f"npm run {key}")
        except Exception:
            pass

    if (root / "go.mod").exists():
        cmds.setdefault("run", "go run .")
        cmds.setdefault("test", "go test ./...")
        cmds.setdefault("build", "go build ./...")

    if (root / "Cargo.toml").exists():
        cmds.setdefault("run", "cargo run")
        cmds.setdefault("test", "cargo test")
        cmds.setdefault("build", "cargo build")
        cmds.setdefault("lint", "cargo clippy")

    if (root / "Makefile").exists() and not cmds:
        cmds["build"] = "make"

    return cmds
